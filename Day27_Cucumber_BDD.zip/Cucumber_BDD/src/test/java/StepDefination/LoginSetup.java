package StepDefination;
/*
import org.openqa.selenium.By; 
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.WebElement; 
import org.openqa.selenium.chrome.ChromeDriver;
import io.cucumber.java.en.And; 
import io.cucumber.java.en.Given; 
import io.cucumber.java.en.Then;
public class LoginSetup { 
	WebDriver driver;
@Given("ebay login page should be open in default browser") 
public void ebay_login_page_should_be_open_in_default_browser() { 
	driver=new ChromeDriver(); 
	driver.get("https://www.ebay.com/"); 
	driver.manage().window().maximize(); 
	} 
@And("click on sign link in home page") 
public void click_on_sign_link_in_home_page() throws InterruptedException { 
	WebElement login=driver.findElement(By.xpath("//*[@id=\"gh\"]/nav/div[1]/span[1]/span/a")); 
	login.click(); 
	Thread.sleep(10000);
} 
@And("click on username and add username") 
public void click_on_username_and_add_username() { 
	WebElement name=driver.findElement(By.id("userid")); 
	name.sendKeys("jayanthyelisetti@gmail.com"); 
	} 
@And("click on continue") 
public void click_on_continue() throws InterruptedException { 
	driver.findElement(By.id("signin-continue-btn")).click(); 
	Thread.sleep(3000); 
	} 
@And("click on password aand add password") 
public void click_on_password_aand_add_password() {
	WebElement pass=driver.findElement(By.id("pass")); 
	pass.sendKeys("Jayanth@2003"); 
	driver.findElement(By.id("sgnBt")).click(); 
	driver.close(); 
	} 
@Then("successful home page is displayed after sign in") 
public void successful_home_page_is_displayed_after_sign_in() {
	System.out.println("Login successful"); 
	}
} */


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import io.cucumber.java.en.*;
import java.time.Duration;

public class LoginSetup {

    WebDriver driver;
    WebDriverWait wait;

    @Given("ebay login page should be open in default browser")
    public void ebay_login_page_should_be_open_in_default_browser() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.ebay.com/");
        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    @When("click on sign link in home page")
    public void click_on_sign_link_in_home_page() {
        WebElement signInLink = wait.until(
            ExpectedConditions.elementToBeClickable(By.linkText("Sign in"))
        );
        signInLink.click();
    }

    @And("click on username and add username")
    public void click_on_username_and_add_username() {
        WebElement usernameField = wait.until(
            ExpectedConditions.visibilityOfElementLocated(By.id("userid"))
        );
        usernameField.sendKeys("jayanthyelisetti@gmail.com"); // Replace with your test account
    }

    @And("click on continue")
    public void click_on_continue() {
        WebElement continueBtn = wait.until(
            ExpectedConditions.elementToBeClickable(By.id("signin-continue-btn"))
        );
        continueBtn.click();
    }

    @And("click on password and add password")
    public void click_on_password_and_add_password() {
        WebElement passwordField = wait.until(
            ExpectedConditions.visibilityOfElementLocated(By.id("pass"))
        );
        passwordField.sendKeys("Jayanth@2003"); // Replace with your test account

        WebElement signInBtn = driver.findElement(By.id("sgnBt"));
        signInBtn.click();
    }

    @Then("successful home page is displayed after sign in")
    public void successful_home_page_is_displayed_after_sign_in() {
        // Wait until home page is loaded after login
        boolean loggedIn = wait.until(
            ExpectedConditions.urlContains("ebay.com")
        );

        if(loggedIn) {
            System.out.println(" Login successful!");
        } else {
            System.out.println(" Login failed!");
        }

        driver.quit();
    }
}