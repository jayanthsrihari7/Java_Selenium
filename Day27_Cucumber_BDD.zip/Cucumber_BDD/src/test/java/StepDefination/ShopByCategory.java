package StepDefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ShopByCategory {
	WebDriver driver;
	@Given("open website ebay")
	public void open_ebay_website() {
		driver=new ChromeDriver(); 
		driver.get("https://www.ebay.com/"); 
		driver.manage().window().maximize(); 
	  
	}

	@When("click on shop by category")
	public void click_on_shop_by_category() throws InterruptedException {
		driver.findElement(By.xpath("//*[@id=\"gh\"]/section/div/div/div/button")).click();
	    Thread.sleep(2000);
	    
	   // driver.findElement(By.linkText("Electronics")).click();
	    //Thread.sleep(3000);
	    driver.findElement(By.linkText("Cell Phones, Smart Watches & Accessories")).click();
	    Thread.sleep(3000);

	    // Click on "iPhone"
	    driver.findElement(By.linkText("iPhone")).click();
	    Thread.sleep(3000);

	    
	}

	@Then("successful shop by category")
	public void successful_shop_by_category() {
		System.out.println("Successful shop by category");
	    
	}



}
